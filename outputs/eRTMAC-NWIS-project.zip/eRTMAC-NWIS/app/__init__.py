"""Nearby Wells Intelligence System."""
